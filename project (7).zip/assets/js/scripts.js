$(function() {
  // Variables
  var $searchInput;
  var $title;
  var $caption;
  
  

  // Dynamic search based on keyup or change in input
  $('#searchInput').on('keyup change', function(){

    // Assign input
    $searchInput = $('#searchInput').val().toLowerCase();


    // Get Titles and Captions
    $('.gallery-item').each(function() {
      $title = $(this).find('img').attr('alt').toLowerCase();
      $caption = $(this).find('a').attr('data-title').toLowerCase();

      $(this).each(function() {

        if ($caption.indexOf($searchInput) === -1) {
          $(this).hide();
        } else {
          $(this).show();
        }


      });

    }); // End Image Loop

    console.log($caption);

  }); // End Search

}); // End jQuery